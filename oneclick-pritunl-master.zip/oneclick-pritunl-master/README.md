# oneclick-pritunl
ดิ้นนนน เข้าไป เอาให้ไข่ถลอก
______________________________________________
**VPN พี่เทพ PRITUNL** 

#ต้นฉบับ

www.pritunl.com

_______________________________________________
Script Install
- Pritunl
- MongoDB
- Vnstat
- Web Server
- Squid Proxy Port 8080,8000,80"

**TimeZone**   :  ไทยโว้ยยยยย

_________________________________________________
**วิธีติดตั้ง**

Ubuntu 14.xx+
```
wget https://raw.githubusercontent.com/d1nfuck3r/oneclick-pritunl/master/install.sh
chmod +x install.sh
./install.sh
```

__________________________________________________
**วิธีติดตั้ง**

Debian8
```
wget https://raw.githubusercontent.com/d1nfuck3r/oneclick-pritunl/master/debian8.sh
chmod +x debian8.sh
./debian8.sh
```

__________________________________________________
**NOTE**

 -เ ฮี ย แ ง ะ งั ย จ ะ คั ย ล่ ะ-
___________________________________________________
